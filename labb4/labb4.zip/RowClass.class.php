<?php
/*Catarina Sörensen
Webbprogrammering
Mittuniversitetet
Denna klassen motsvaren en rad i listan för att få bättre struktur på koden.
*/
   class RowClass{
      public $name;
      public $last;
      public $userid;
    }

?>
